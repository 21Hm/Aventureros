/**
 * Los Aventureros · CDMX 2026
 * API (Google Apps Script) conectada a la hoja "Tareas". La interfaz está en GitHub Pages.
 *
 * Columnas que usa la app:
 *   A ✓ completada (la app la marca/desmarca)
 *   K Notas (editable desde la app)
 *   L Imágenes  -> link a la carpeta de Drive de la actividad (lo llena la app)
 *   M Portada   -> link a la foto de portada (lo llenas tú)
 *   N ID app    -> identificador interno de cada actividad (lo llena la app, no tocar)
 *   O Lugar (app) -> lugar escrito desde la app para actividades TBD
 *   P Calificación promedio (lo llena la app)
 * Hoja extra "Calificaciones": una fila por persona y actividad.
 */

var CONFIG = {
  HOJA: 'Tareas',
  HOJA_CALIF: 'Calificaciones',
  PRIMERA_FILA: 4,
  FILA_ENCABEZADOS: 3,
  CARPETA_RAIZ: 'Los Aventureros · CDMX 2026',
  COL: { HECHA: 1, TAREA: 4, NOTAS: 11, CARPETA: 12, PORTADA: 13, ID: 14, LUGAR: 15, PROMEDIO: 16 }
};

/* ------------------------------- API -------------------------------- */
/* La interfaz vive en GitHub Pages y llama a este script con fetch(). */

var ACCIONES = {
  getData: getData,
  calificar: calificar,
  marcarHecha: marcarHecha,
  guardarDetalles: guardarDetalles,
  subirFoto: subirFoto,
  fotos: fotos
};

function doGet(e) {
  var accion = e && e.parameter && e.parameter.accion;
  if (!accion) return json_({ ok: true, app: 'Los Aventureros', mensaje: 'API funcionando' });
  var args = e.parameter.args ? JSON.parse(e.parameter.args) : [];
  return ejecutar_(accion, args);
}

function doPost(e) {
  var cuerpo = {};
  try { cuerpo = JSON.parse((e && e.postData && e.postData.contents) || '{}'); } catch (err) {}
  return ejecutar_(cuerpo.accion, cuerpo.args || []);
}

function ejecutar_(accion, args) {
  try {
    if (!Object.prototype.hasOwnProperty.call(ACCIONES, accion)) throw new Error('Acción desconocida: ' + accion);
    return json_({ ok: true, data: ACCIONES[accion].apply(null, args) });
  } catch (err) {
    return json_({ ok: false, error: String((err && err.message) || err) });
  }
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function onOpen() {
  SpreadsheetApp.getUi().createMenu('Los Aventureros')
    .addItem('Preparar app (IDs, mapas y carpetas)', 'prepararApp')
    .addToUi();
}

/** Ejecútala una vez desde el editor: autoriza permisos y deja todo listo. */
function prepararApp() {
  asegurarColumnas_();
  var datos = leerItinerario_({ resolverMapas: 60 });
  datos.paradas.forEach(function (p) { carpetaDeParada_(p, true); });
  SpreadsheetApp.getActive().toast('Listo: ' + datos.paradas.length + ' actividades preparadas.', 'Los Aventureros', 5);
}

/* --------------------------- API pública --------------------------- */

function getData() {
  var datos = leerItinerario_({ resolverMapas: 8 });
  return JSON.stringify({
    paradas: datos.paradas,
    calificaciones: leerCalificaciones_(),
    ahora: Date.now()
  });
}

function calificar(id, persona, estrellas) {
  persona = limpiarNombre_(persona);
  estrellas = Math.max(0, Math.min(5, Math.round(Number(estrellas) || 0)));
  if (!id || !persona) throw new Error('Falta la actividad o el nombre.');
  return conCandado_(function () {
    var hoja = hojaCalificaciones_();
    var valores = hoja.getDataRange().getValues();
    var fila = -1;
    for (var i = 1; i < valores.length; i++) {
      if (String(valores[i][0]) === id && String(valores[i][2]).toLowerCase() === persona.toLowerCase()) { fila = i + 1; break; }
    }
    var info = buscarFilaPorId_(id);
    var titulo = info ? info.titulo : '';
    if (estrellas === 0) {
      if (fila > 0) hoja.deleteRow(fila);
    } else if (fila > 0) {
      hoja.getRange(fila, 4, 1, 2).setValues([[estrellas, new Date()]]);
    } else {
      hoja.appendRow([id, titulo, persona, estrellas, new Date()]);
    }
    var todas = leerCalificaciones_();
    if (info) {
      var votos = todas[id] || {};
      var nums = Object.keys(votos).map(function (k) { return votos[k]; });
      var prom = nums.length ? nums.reduce(function (a, b) { return a + b; }, 0) / nums.length : '';
      hojaTareas_().getRange(info.row, CONFIG.COL.PROMEDIO).setValue(prom === '' ? '' : Math.round(prom * 10) / 10);
    }
    return JSON.stringify(todas[id] || {});
  });
}

function marcarHecha(id, hecha) {
  return conCandado_(function () {
    var info = buscarFilaPorId_(id);
    if (!info) throw new Error('No encontré la actividad en la hoja.');
    hojaTareas_().getRange(info.row, CONFIG.COL.HECHA).setValue(!!hecha);
    return !!hecha;
  });
}

/** cambios: {titulo, lugar, notas} — cualquier campo puede venir vacío. */
function guardarDetalles(id, cambios) {
  return conCandado_(function () {
    var info = buscarFilaPorId_(id);
    if (!info) throw new Error('No encontré la actividad en la hoja.');
    var hoja = hojaTareas_();
    if (cambios.titulo != null && String(cambios.titulo).trim()) hoja.getRange(info.row, CONFIG.COL.TAREA).setValue(String(cambios.titulo).trim());
    if (cambios.lugar != null) hoja.getRange(info.row, CONFIG.COL.LUGAR).setValue(String(cambios.lugar).trim());
    if (cambios.notas != null) hoja.getRange(info.row, CONFIG.COL.NOTAS).setValue(String(cambios.notas).trim());
    SpreadsheetApp.flush();
    var datos = leerItinerario_({ resolverMapas: 2 });
    var p = datos.paradas.filter(function (x) { return x.id === id; })[0];
    return JSON.stringify(p || null);
  });
}

function subirFoto(id, nombre, mime, base64) {
  if (!/^image\//.test(mime || '')) throw new Error('Solo se pueden subir imágenes.');
  var carpeta = conCandado_(function () {
    var info = buscarFilaPorId_(id);
    if (!info) throw new Error('No encontré la actividad en la hoja.');
    return carpetaDeParada_(info, true);
  });
  var blob = Utilities.newBlob(Utilities.base64Decode(base64), mime, nombre || ('foto-' + Date.now() + '.jpg'));
  var archivo = carpeta.createFile(blob);
  try { archivo.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch (e) {}
  return JSON.stringify({ carpeta: carpeta.getUrl(), foto: fotoInfo_(archivo) });
}

function fotos(id) {
  var info = buscarFilaPorId_(id);
  if (!info || !info.carpeta) return JSON.stringify([]);
  var carpeta = carpetaDesdeUrl_(info.carpeta);
  if (!carpeta) return JSON.stringify([]);
  var lista = [];
  var it = carpeta.getFiles();
  while (it.hasNext() && lista.length < 40) {
    var f = it.next();
    if (/^image\//.test(f.getMimeType())) lista.push(fotoInfo_(f));
  }
  lista.sort(function (a, b) { return a.t - b.t; });
  return JSON.stringify(lista);
}

/* ---------------------------- Internos ----------------------------- */

function hojaTareas_() { return SpreadsheetApp.getActive().getSheetByName(CONFIG.HOJA); }

function hojaCalificaciones_() {
  var ss = SpreadsheetApp.getActive();
  var h = ss.getSheetByName(CONFIG.HOJA_CALIF);
  if (!h) {
    h = ss.insertSheet(CONFIG.HOJA_CALIF);
    h.appendRow(['ID app', 'Actividad', 'Persona', 'Estrellas', 'Actualizado']);
    h.setFrozenRows(1);
  }
  return h;
}

function asegurarColumnas_() {
  var hoja = hojaTareas_();
  if (hoja.getMaxColumns() < CONFIG.COL.PROMEDIO) hoja.insertColumnsAfter(hoja.getMaxColumns(), CONFIG.COL.PROMEDIO - hoja.getMaxColumns());
  var enc = hoja.getRange(CONFIG.FILA_ENCABEZADOS, CONFIG.COL.ID, 1, 3);
  var v = enc.getValues()[0];
  var nuevos = ['ID app (no tocar)', 'Lugar (app)', 'Calificación ⭐'];
  if (v.join('') === '') enc.setValues([nuevos]);
}

function leerItinerario_(opts) {
  asegurarColumnas_();
  var ss = SpreadsheetApp.getActive();
  var hoja = hojaTareas_();
  var ultima = hoja.getLastRow();
  var rango = "'" + CONFIG.HOJA + "'!A1:P" + ultima;
  var resp = Sheets.Spreadsheets.get(ss.getId(), {
    ranges: [rango],
    includeGridData: true,
    fields: 'sheets(merges,data(rowMetadata(hiddenByUser),rowData(values(formattedValue,hyperlink,userEnteredValue(formulaValue),textFormatRuns(format(link(uri))),chipRuns(chip(richLinkProperties(uri)))))))'
  });
  var filas = filasDesdeGrid(resp.sheets[0], CONFIG.PRIMERA_FILA);
  var res = construirItinerario(filas);

  // IDs para actividades nuevas
  var faltan = res.paradas.filter(function (p) { return !p.id; });
  if (faltan.length) {
    faltan.forEach(function (p) {
      p.id = Utilities.getUuid().slice(0, 8);
      hoja.getRange(p.row, CONFIG.COL.ID).setValue(p.id);
    });
  }

  // Coordenadas para Apple Maps (se guardan en caché)
  var presupuesto = (opts && opts.resolverMapas) || 0;
  var props = PropertiesService.getScriptProperties();
  res.paradas.forEach(function (p) {
    [p.lugar, p.origen, p.destino].forEach(function (l) {
      if (!l || l.lat != null || !l.url) return;
      var clave = 'geo:' + l.url.slice(0, 200);
      var guardado = props.getProperty(clave);
      if (guardado == null && presupuesto > 0) {
        presupuesto--;
        var c = resolverCoordenadas_(l.url);
        guardado = c ? c.lat + ',' + c.lng : '';
        props.setProperty(clave, guardado);
      }
      if (guardado) {
        var partes = guardado.split(',');
        l.lat = Number(partes[0]); l.lng = Number(partes[1]);
      }
    });
  });
  return res;
}

function resolverCoordenadas_(url) {
  var actual = url;
  for (var i = 0; i < 5; i++) {
    var c = coordsFromUrl_(actual);
    if (c) return c;
    try {
      var r = UrlFetchApp.fetch(actual, { followRedirects: false, muteHttpExceptions: true });
      var h = r.getAllHeaders();
      var loc = h.Location || h.location;
      if (!loc) {
        var html = r.getContentText().slice(0, 20000);
        return coordsFromUrl_(html) || null;
      }
      actual = Array.isArray(loc) ? loc[0] : loc;
    } catch (e) { return null; }
  }
  return coordsFromUrl_(actual);
}

function buscarFilaPorId_(id) {
  var hoja = hojaTareas_();
  var ultima = hoja.getLastRow();
  var n = ultima - CONFIG.PRIMERA_FILA + 1;
  if (n <= 0) return null;
  var ids = hoja.getRange(CONFIG.PRIMERA_FILA, CONFIG.COL.ID, n, 1).getValues();
  for (var i = 0; i < ids.length; i++) {
    if (String(ids[i][0]) === String(id)) {
      var row = CONFIG.PRIMERA_FILA + i;
      var fila = hoja.getRange(row, 1, 1, CONFIG.COL.PROMEDIO).getDisplayValues()[0];
      var carpetaCelda = hoja.getRange(row, CONFIG.COL.CARPETA);
      var link = '';
      try { link = carpetaCelda.getRichTextValue().getLinkUrl() || ''; } catch (e) {}
      return { row: row, id: id, fecha: fila[1], inicio: fila[2], titulo: fila[3], carpeta: link || fila[CONFIG.COL.CARPETA - 1] };
    }
  }
  return null;
}

function carpetaRaiz_() {
  var props = PropertiesService.getScriptProperties();
  var id = props.getProperty('carpetaRaiz');
  if (id) { try { return DriveApp.getFolderById(id); } catch (e) {} }
  var c = DriveApp.createFolder(CONFIG.CARPETA_RAIZ);
  try { c.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch (e) {}
  props.setProperty('carpetaRaiz', c.getId());
  return c;
}

function carpetaDesdeUrl_(url) {
  var m = String(url || '').match(/folders\/([\w-]{10,})/) || String(url || '').match(/[?&]id=([\w-]{10,})/);
  if (!m) return null;
  try { return DriveApp.getFolderById(m[1]); } catch (e) { return null; }
}

/** info: {row, fecha, inicio, titulo, carpeta} o una parada. Crea la carpeta si no existe y la anota en L. */
function carpetaDeParada_(info, crear) {
  var existente = carpetaDesdeUrl_(info.carpeta);
  if (existente || !crear) return existente;
  var fecha = String(info.fecha || '').replace('/', '-');
  var titulo = String(info.tituloOriginal || info.titulo || 'Actividad').replace(/[\\/:*?"<>|]/g, ' ');
  var nombre = (fecha ? fecha + ' · ' : '') + titulo;
  var c = carpetaRaiz_().createFolder(nombre);
  try { c.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch (e) {}
  var celda = hojaTareas_().getRange(info.row, CONFIG.COL.CARPETA);
  celda.setRichTextValue(SpreadsheetApp.newRichTextValue().setText('📷 Fotos').setLinkUrl(c.getUrl()).build());
  info.carpeta = c.getUrl();
  return c;
}

function fotoInfo_(f) {
  return {
    id: f.getId(),
    mini: 'https://drive.google.com/thumbnail?id=' + f.getId() + '&sz=w400',
    grande: 'https://drive.google.com/thumbnail?id=' + f.getId() + '&sz=w2000',
    url: f.getUrl(),
    t: f.getDateCreated().getTime()
  };
}

function leerCalificaciones_() {
  var valores = hojaCalificaciones_().getDataRange().getValues();
  var out = {};
  for (var i = 1; i < valores.length; i++) {
    var id = String(valores[i][0]), persona = String(valores[i][2]), n = Number(valores[i][3]);
    if (!id || !persona || !n) continue;
    (out[id] = out[id] || {})[persona] = n;
  }
  return out;
}

function limpiarNombre_(s) {
  s = String(s || '').trim().replace(/\s+/g, ' ').slice(0, 30);
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : '';
}

function conCandado_(fn) {
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try { return fn(); } finally { lock.releaseLock(); }
}

