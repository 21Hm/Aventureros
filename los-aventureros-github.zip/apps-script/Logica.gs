/**
 * Lógica pura: convierte las filas de la hoja en actividades + traslados.
 * No usa servicios de Google, así se puede probar fuera de Apps Script.
 */

var LOGICA = {
  YEAR: 2026,
  UTC_OFFSET_HOURS: -6 // Ciudad de México (sin horario de verano)
};

var RX_MOVE = /^\s*(traslado|regreso)\b/i;
var RX_REST = /^\s*(dormir|descanso|recoger maletas)/i;
var RX_FLIGHT = /\bvuelo\b/i;
var RX_ARRIVAL = /^\s*llegada\b/i;
var RX_COORDS = /^\s*\d{1,3}\s*°/;

function parseFecha_(txt) {
  var m = String(txt || '').match(/(\d{1,2})\s*\/\s*(\d{1,2})(?:\s*\/\s*(\d{2,4}))?/);
  if (!m) return null;
  var y = m[3] ? (m[3].length === 2 ? 2000 + Number(m[3]) : Number(m[3])) : LOGICA.YEAR;
  return { d: Number(m[1]), m: Number(m[2]), y: y };
}

function parseHora_(txt) {
  var m = String(txt || '').trim().match(/^(\d{1,2})(?::(\d{2}))?\s*([ap])\.?\s*m\.?/i);
  if (!m) {
    var m24 = String(txt || '').trim().match(/^(\d{1,2}):(\d{2})$/);
    if (!m24) return null;
    return Number(m24[1]) * 60 + Number(m24[2]);
  }
  var h = Number(m[1]) % 12;
  if (m[3].toLowerCase() === 'p') h += 12;
  return h * 60 + Number(m[2] || 0);
}

function toEpoch_(fecha, minutos) {
  // hora local CDMX -> UTC
  return Date.UTC(fecha.y, fecha.m - 1, fecha.d, 0, minutos) - LOGICA.UTC_OFFSET_HOURS * 3600000;
}

function parseDMS_(txt) {
  var m = String(txt || '').match(/(\d+)\s*°\s*(\d+)\s*'\s*([\d.]+)\s*"\s*([NS])\s+(\d+)\s*°\s*(\d+)\s*'\s*([\d.]+)\s*"\s*([EW])/i);
  if (!m) return null;
  var lat = Number(m[1]) + Number(m[2]) / 60 + Number(m[3]) / 3600;
  var lng = Number(m[5]) + Number(m[6]) / 60 + Number(m[7]) / 3600;
  if (/S/i.test(m[4])) lat = -lat;
  if (/W/i.test(m[8])) lng = -lng;
  return { lat: Math.round(lat * 1e6) / 1e6, lng: Math.round(lng * 1e6) / 1e6 };
}

function coordsFromUrl_(url) {
  url = String(url || '');
  var m = url.match(/!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/) ||
          url.match(/@(-?\d+\.\d+),(-?\d+\.\d+)/) ||
          url.match(/[?&](?:q|query|ll|destination)=(-?\d+\.\d+),\s*(-?\d+\.\d+)/);
  return m ? { lat: Number(m[1]), lng: Number(m[2]) } : null;
}

function esUrl_(s) { return /^https?:\/\//i.test(String(s || '').trim()); }

function categoria_(titulo) {
  var t = String(titulo || '').toLowerCase();
  if (RX_FLIGHT.test(t)) return 'vuelo';
  if (/prepara|getting ready/.test(t)) return 'ready';
  if (/concierto|tour|musical|ballet|rey le[oó]n|show/.test(t)) return 'show';
  if (/rosso|speakeasy|canta coraz|bar\b|cantina/.test(t)) return 'noche';
  if (/museo|casa azul|castillo|simi|soumaya|jumex|antropolog|bellas artes/.test(t)) return 'museo';
  if (/desayuno|almuerzo|comida|cena|taquer|panader|caf[eé]|snack|applebee|pasteler|orinoco|califa|ideal/.test(t)) return 'comida';
  return 'paseo';
}

function tituloBonito_(titulo) {
  var t = String(titulo || '').trim();
  if (/^preparaci[oó]n para (el )?concierto/i.test(t)) return 'Getting ready';
  return t.replace(/\s*[-–]\s*TBD\s*$/i, '').trim() || t;
}

function lugarDesdeTexto_(texto, url) {
  texto = String(texto || '').trim();
  if (!texto && !url) return null;
  if (esUrl_(texto)) { url = url || texto; texto = ''; }
  var coords = parseDMS_(texto) || coordsFromUrl_(url);
  var esAirbnb = RX_COORDS.test(texto);
  return {
    nombre: esAirbnb ? 'Airbnb' : texto,
    url: url || '',
    lat: coords ? coords.lat : null,
    lng: coords ? coords.lng : null
  };
}

/**
 * filas: [{row, done, fecha, inicio, titulo, fin, desde:{text,url}, flecha, hacia:{text,url},
 *          duracion, notas, carpeta, portada, id, lugarApp, finFila}]
 *   finFila = última fila que cubre la celda unida de "Tarea" (o la misma fila).
 *   Las filas dentro de una celda unida (que no son la primera) traen dentroDeUnion=true.
 */
function construirItinerario(filas) {
  var paradas = [];
  var pendiente = nuevoConector_();
  var llegada = null;
  var ultimaFecha = null;
  var ultimoFueParada = false;

  var porFila = {};
  filas.forEach(function (f) { porFila[f.row] = f; });

  for (var i = 0; i < filas.length; i++) {
    var f = filas[i];
    if (f.dentroDeUnion) continue;

    var fecha = parseFecha_(f.fecha) || ultimaFecha;
    if (fecha) ultimaFecha = fecha;
    var titulo = String(f.titulo || '').trim();

    var filaFin = porFila[f.finFila] || f;
    var finTxt = filaFin.fin || f.fin;
    // si la última fila de la unión no trae fin, buscar hacia arriba
    if (!finTxt) {
      for (var r = f.finFila; r >= f.row; r--) { if (porFila[r] && porFila[r].fin) { finTxt = porFila[r].fin; break; } }
    }
    var tIni = fecha ? parseHora_(f.inicio) : null;
    var tFin = fecha ? parseHora_(finTxt) : null;
    var ini = (tIni != null) ? toEpoch_(fecha, tIni) : null;
    var fin = (tFin != null) ? toEpoch_(fecha, tFin) : null;
    if (ini != null && fin != null && fin <= ini) fin += 86400000;

    var tramo = { row: f.row, titulo: titulo, inicio: ini, fin: fin, duracion: f.duracion || '', notas: f.notas || '' };

    if (!titulo) {
      var ult = paradas[paradas.length - 1];
      var hacia = String(f.hacia && f.hacia.text || '').trim();
      var desdeTxt = String(f.desde && f.desde.text || '').trim();
      var esViaje = String(f.flecha || '').trim() === '-' && hacia && hacia !== desdeTxt;
      if (ultimoFueParada && ult && !esViaje) {
        if (fin != null) ult.fin = Math.max(ult.fin || 0, fin);
        continue;
      }
      if (esViaje) {
        tramo.titulo = 'Traslado a ' + (RX_COORDS.test(hacia) ? 'Airbnb' : hacia);
        pendiente.traslados.push(enriquecerTraslado_(tramo));
        ultimoFueParada = false;
      }
      continue;
    }

    if (RX_REST.test(titulo)) {
      pendiente.pausas.push(tramo);
      if (tramo.notas && pendiente.avisos.indexOf(tramo.notas) < 0) pendiente.avisos.push(tramo.notas);
      ultimoFueParada = false;
      continue;
    }
    if (RX_MOVE.test(titulo)) {
      pendiente.traslados.push(enriquecerTraslado_(tramo));
      ultimoFueParada = false;
      continue;
    }
    if (RX_ARRIVAL.test(titulo)) {
      llegada = { inicio: ini, titulo: titulo, lugar: lugarDeFila_(f) };
      continue;
    }

    var esVuelo = RX_FLIGHT.test(titulo);
    var p = {
      id: f.id || '',
      row: f.row,
      tipo: esVuelo ? 'vuelo' : 'actividad',
      tituloOriginal: titulo,
      fecha: f.fecha || '',
      titulo: tituloBonito_(titulo),
      categoria: categoria_(titulo),
      inicio: ini,
      fin: fin,
      llegada: null,
      lugar: null,
      origen: null,
      destino: null,
      notas: String(f.notas || '').trim(),
      avisos: pendiente.avisos.slice(),
      portada: normalizarPortada_(f.portada),
      carpeta: String(f.carpeta || '').trim(),
      hecha: f.done === true || String(f.done).toUpperCase() === 'TRUE',
      conectorAntes: pendiente
    };

    if (esVuelo) {
      p.origen = lugarDesdeTexto_(f.desde && f.desde.text, f.desde && f.desde.url);
      p.destino = lugarDesdeTexto_(f.hacia && f.hacia.text, f.hacia && f.hacia.url);
      p.lugar = p.origen;
    } else {
      var anterior = paradas[paradas.length - 1];
      p.lugar = lugarDeFila_(f, anterior && anterior.lugar && anterior.lugar.nombre);
    }

    if (llegada) {
      p.llegada = llegada.inicio;
      if (!p.lugar) p.lugar = llegada.lugar;
      llegada = null;
    }
    if (f.lugarApp) {
      var la = String(f.lugarApp).trim();
      p.lugar = esUrl_(la) ? lugarDesdeTexto_(p.titulo, la) : lugarDesdeTexto_(la, '');
      p.lugarEditado = la;
    }

    var notaTBD = /^\s*TBD\s*$/i.test(p.notas);
    if (notaTBD) p.notas = '';
    p.tbd = /\bTBD\b/i.test(titulo) || notaTBD || (!p.lugar && !esVuelo);

    paradas.push(p);
    pendiente = nuevoConector_();
    ultimoFueParada = true;
  }

  return { paradas: paradas, conectorFinal: pendiente };
}

function nuevoConector_() { return { traslados: [], pausas: [], avisos: [] }; }

function enriquecerTraslado_(t) {
  t.aPie = /a pie|caminando/i.test(t.titulo);
  return t;
}

function lugarDeFila_(f, lugarAnterior) {
  var desde = f.desde || {}, hacia = f.hacia || {};
  var haciaTxt = String(hacia.text || '').trim();
  var flecha = String(f.flecha || '').trim();
  if (haciaTxt && !RX_COORDS.test(haciaTxt)) return lugarDesdeTexto_(haciaTxt, hacia.url);
  // "Desde X -> (vacío)": si X es donde estábamos antes, el destino aún no está definido (TBD)
  if (flecha === '-' && !haciaTxt && desde.text && desde.text.trim() === lugarAnterior) return null;
  if (desde.text || desde.url) return lugarDesdeTexto_(desde.text, desde.url);
  if (haciaTxt) return lugarDesdeTexto_(haciaTxt, hacia.url);
  return null;
}

function normalizarPortada_(v) {
  var s = String(v || '').trim();
  if (!s) return '';
  var img = s.match(/IMAGE\(\s*"([^"]+)"/i);
  if (img) s = img[1];
  var drive = s.match(/drive\.google\.com\/(?:file\/d\/|open\?id=|uc\?(?:export=\w+&)?id=)([\w-]{10,})/);
  if (drive) return 'https://drive.google.com/thumbnail?id=' + drive[1] + '&sz=w1600';
  return esUrl_(s) ? s : '';
}

/**
 * Convierte la respuesta de la API de Sheets (con includeGridData) en filas.
 * hoja = spreadsheet.sheets[0]; el rango debe empezar en A1.
 * Columnas: A ✓ | B Fecha | C Inicio | D Tarea | E Fin | G Desde | H - | I Hacia | J Duración |
 *           K Notas | L Imágenes | M Portada | N ID app | O Lugar (app)
 */
function filasDesdeGrid(hoja, primeraFila) {
  var data = (hoja.data && hoja.data[0]) || {};
  var rowData = data.rowData || [];
  var meta = data.rowMetadata || [];
  var celdas = rowData.map(function (r) {
    return (r.values || []).map(function (c) {
      var url = c.hyperlink || '';
      (c.textFormatRuns || []).forEach(function (tr) {
        var u = tr.format && tr.format.link && tr.format.link.uri;
        if (u && !url) url = u;
      });
      (c.chipRuns || []).forEach(function (cr) {
        var u = cr.chip && cr.chip.richLinkProperties && cr.chip.richLinkProperties.uri;
        if (u) url = u;
      });
      var formula = c.userEnteredValue && c.userEnteredValue.formulaValue;
      return { v: c.formattedValue != null ? String(c.formattedValue) : '', url: url, formula: formula || '' };
    });
  });
  var get = function (r, c) { return (celdas[r] && celdas[r][c]) || { v: '', url: '', formula: '' }; };
  var finFila = {}, dentro = {};
  (hoja.merges || []).forEach(function (m) {
    var top = get(m.startRowIndex, m.startColumnIndex);
    for (var r = m.startRowIndex; r < m.endRowIndex; r++) {
      for (var c = m.startColumnIndex; c < m.endColumnIndex; c++) {
        if (r === m.startRowIndex && c === m.startColumnIndex) continue;
        if (!celdas[r]) celdas[r] = [];
        celdas[r][c] = { v: top.v, url: top.url, formula: top.formula, unida: true };
      }
    }
    if (m.startColumnIndex <= 3 && m.endColumnIndex > 3 && m.endRowIndex - m.startRowIndex > 1) {
      finFila[m.startRowIndex + 1] = m.endRowIndex; // 1-based última fila
      for (var rr = m.startRowIndex + 1; rr < m.endRowIndex; rr++) dentro[rr + 1] = true;
    }
  });

  var filas = [];
  for (var i = primeraFila - 1; i < celdas.length; i++) {
    var row = i + 1;
    var portada = get(i, 12);
    filas.push({
      row: row,
      oculta: !!(meta[i] && meta[i].hiddenByUser),
      done: get(i, 0).v,
      fecha: get(i, 1).v,
      inicio: get(i, 2).v,
      titulo: get(i, 3).v,
      fin: get(i, 4).v,
      desde: { text: get(i, 6).v, url: get(i, 6).url },
      flecha: get(i, 7).v,
      hacia: { text: get(i, 8).v, url: get(i, 8).url },
      duracion: get(i, 9).v,
      notas: get(i, 10).v,
      carpeta: get(i, 11).url || get(i, 11).v,
      portada: portada.formula || portada.url || portada.v,
      id: get(i, 13).v,
      lugarApp: get(i, 14).v,
      finFila: finFila[row] || row,
      dentroDeUnion: !!dentro[row]
    });
  }
  return filas;
}

if (typeof module !== 'undefined') {
  module.exports = { construirItinerario: construirItinerario, filasDesdeGrid: filasDesdeGrid, parseHora_: parseHora_, parseDMS_: parseDMS_, coordsFromUrl_: coordsFromUrl_, normalizarPortada_: normalizarPortada_ };
}
